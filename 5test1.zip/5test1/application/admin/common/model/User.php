<?php 
namespace app\admin\common\model;

use think\Model;

class User extends Model 
{
	protected $pk = 'id';
	protected $table = 'zh_user';
}